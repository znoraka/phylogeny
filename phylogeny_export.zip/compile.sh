#!/bin/sh

root=$PWD
for d in */
do
    cd $root/$d
    if [ -d "c++" ]; then
	cd "c++"
    fi
    cmake .
    make
done
