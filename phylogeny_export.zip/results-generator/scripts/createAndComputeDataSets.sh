#!/bin/sh

if [ ! -d "$2" ]; then
    mkdir $2
fi

if [ ! -d "$3/data" ]; then
    mkdir $3/data
fi

COUNTER=$(cd $2 && ls -l | grep -v ^l | wc -l)
COUNTER=$((COUNTER - 1))

for i in $(seq 0 $5)
do
    for f in $1/*.pgm
    do
	echo "file = " $f
	mkdir $2/$COUNTER

	rm -rf $3/data
	mkdir $3/data

	../../tree-generator/bin/tree-generator $3/data/ $f $4 0 $2/$COUNTER

	../../tree-extractor/bin/tree-extractor $3/data $2/$COUNTER $3
	../../tree-comparator/bin/tree-comparator $2/$COUNTER/truth.txt $2/$COUNTER/computed.txt >> $2/$COUNTER/results.txt
	
	COUNTER=$((COUNTER + 1))
    done
done

echo "\n\n\tResults on dataset:\n"
../c++/bin/results-generator $2
